# WidgetDoodles

[[JSBox](https://apps.apple.com/cn/app/id1312014438) 脚本] 使用 iOS 14 小组件功能，实现在桌面上放置您的涂鸦作品。

# 配置

- 创建涂鸦
- 复制涂鸦到剪贴板
- 添加小组件到桌面（[教程](https://support.apple.com/zh-cn/HT207122)）
- 编辑小组件，选择 WidgetDoodles 作为脚本
- 将涂鸦粘贴到“输入参数”那一栏
- 完成