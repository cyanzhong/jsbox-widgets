# WidgetDoodles

[[JSBox](https://apps.apple.com/us/app/id1312014438) script] Doodles on your home screen, using iOS 14 widgets.

# Configuration

- Create doodles
- Copy the doodles to clipboard
- Add a widget to your home screen ([Guide](https://support.apple.com/en-us/HT207122))
- Edit the widget, choose WidgetDoodles as the script
- Paste the doodles to the "Input Value" field
- Done